/**
 */
package pt.fct.unl.novalincs.useme.model.ContextModeling.impl;

import org.eclipse.emf.ecore.EClass;

import pt.fct.unl.novalincs.useme.model.ContextModeling.ContextModelingPackage;
import pt.fct.unl.novalincs.useme.model.ContextModeling.TechnicalEnvironment;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Technical Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TechnicalEnvironmentImpl extends ContextEnvironmentImpl implements TechnicalEnvironment {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TechnicalEnvironmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContextModelingPackage.Literals.TECHNICAL_ENVIRONMENT;
	}

} //TechnicalEnvironmentImpl
