/**
 */
package pt.fct.unl.novalincs.useme.model.ContextModeling;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Physical Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pt.fct.unl.novalincs.useme.model.ContextModeling.ContextModelingPackage#getPhysicalEnvironment()
 * @model
 * @generated
 */
public interface PhysicalEnvironment extends ContextEnvironment {
} // PhysicalEnvironment
