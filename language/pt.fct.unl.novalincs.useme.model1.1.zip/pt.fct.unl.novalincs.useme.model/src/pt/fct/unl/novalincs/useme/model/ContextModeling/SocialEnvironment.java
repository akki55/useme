/**
 */
package pt.fct.unl.novalincs.useme.model.ContextModeling;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Social Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pt.fct.unl.novalincs.useme.model.ContextModeling.ContextModelingPackage#getSocialEnvironment()
 * @model
 * @generated
 */
public interface SocialEnvironment extends ContextEnvironment {
} // SocialEnvironment
