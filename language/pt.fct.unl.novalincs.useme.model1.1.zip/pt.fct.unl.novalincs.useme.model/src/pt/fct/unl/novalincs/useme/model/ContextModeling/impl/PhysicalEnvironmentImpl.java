/**
 */
package pt.fct.unl.novalincs.useme.model.ContextModeling.impl;

import org.eclipse.emf.ecore.EClass;

import pt.fct.unl.novalincs.useme.model.ContextModeling.ContextModelingPackage;
import pt.fct.unl.novalincs.useme.model.ContextModeling.PhysicalEnvironment;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Physical Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PhysicalEnvironmentImpl extends ContextEnvironmentImpl implements PhysicalEnvironment {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PhysicalEnvironmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContextModelingPackage.Literals.PHYSICAL_ENVIRONMENT;
	}

} //PhysicalEnvironmentImpl
