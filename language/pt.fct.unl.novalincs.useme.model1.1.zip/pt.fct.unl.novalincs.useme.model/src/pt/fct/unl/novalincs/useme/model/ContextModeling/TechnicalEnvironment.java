/**
 */
package pt.fct.unl.novalincs.useme.model.ContextModeling;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Technical Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pt.fct.unl.novalincs.useme.model.ContextModeling.ContextModelingPackage#getTechnicalEnvironment()
 * @model
 * @generated
 */
public interface TechnicalEnvironment extends ContextEnvironment {
} // TechnicalEnvironment
