/**
 */
package pt.fct.unl.novalincs.useme.model.ContextModeling.impl;

import org.eclipse.emf.ecore.EClass;

import pt.fct.unl.novalincs.useme.model.ContextModeling.ContextModelingPackage;
import pt.fct.unl.novalincs.useme.model.ContextModeling.SocialEnvironment;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Social Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SocialEnvironmentImpl extends ContextEnvironmentImpl implements SocialEnvironment {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SocialEnvironmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContextModelingPackage.Literals.SOCIAL_ENVIRONMENT;
	}

} //SocialEnvironmentImpl
